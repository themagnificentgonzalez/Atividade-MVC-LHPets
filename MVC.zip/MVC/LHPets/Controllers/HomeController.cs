using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using LHPets.Models;

namespace LHPets.Controllers;

public class HomeController : Controller
{
    private readonly ILogger<HomeController> _logger;

    public HomeController(ILogger<HomeController> logger)
    {
        _logger = logger;
    }

    public IActionResult Index()
    {
        //instâncias do tipo cliente
        Cliente cliente1 = new Cliente( 1, "Zé", "001.002.003-01", "ze@tudo.com", "Rufus");
        Cliente cliente2 = new Cliente( 2, "Nel", "001.002.003-02", "nel@tudo.com", "Spector");
        Cliente cliente3 = new Cliente( 3, "Mel", "001.002.003-03", "mel@tudo.com", "Nell");
        Cliente cliente4 = new Cliente( 4, "Bia", "001.002.003-04", "bia@tudo.com", "Banha");
        Cliente cliente5 = new Cliente( 5, "Lia", "001.002.003-05", "lia@tudo.com", "Bela");

//lista e atribuição MANUAL dos clientes
        List <Cliente> listaClientes = new List<Cliente>();
            listaClientes.Add(cliente1);
            listaClientes.Add(cliente2);
            listaClientes.Add(cliente3);
            listaClientes.Add(cliente4);
            listaClientes.Add(cliente5);

        //instâncias do tipo fornecedor
        Fornecedor fornecedor1 = new Fornecedor (1, "Boa Alimentos", "01.002.003/0001-01", "vendas@boaalimentos.com.br");
        Fornecedor fornecedor2 = new Fornecedor (2, "Boa Brinquedos", "01.002.003/0001-02", "vendas@boabrinquedos.com.br");
        Fornecedor fornecedor3 = new Fornecedor (3, "Boa Higiene", "01.002.003/0001-03", "vendas@boahigiene.com.br");
        Fornecedor fornecedor4 = new Fornecedor (4, "Boa Plantas", "01.002.003/0001-04", "vendas@boaplantas.com.br");
        Fornecedor fornecedor5 = new Fornecedor (5, "Boa Gaiolas", "01.002.003/0001-05", "vendas@boagaiolas.com.br");
        
    ViewBag.listaClientes = listaClientes;

//lista e atribuição MANUAL dos fornecedores        
        List <Fornecedor> listaFornecedores = new List<Fornecedor>();
            listaFornecedores.Add(fornecedor1);
            listaFornecedores.Add(fornecedor2);
            listaFornecedores.Add(fornecedor3);
            listaFornecedores.Add(fornecedor4);
            listaFornecedores.Add(fornecedor5);
        
    ViewBag.listaFornecedores = listaFornecedores;

        return View();
    }

    public IActionResult Privacy()
    {
        return View();
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}
